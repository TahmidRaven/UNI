-- If a student doesn't exist, just write N/A (like student 5 right now)

student_1 = {}
student_1["id"] = "14101032"
student_1["name"] = "Name Random"

student_2 = {}
student_2["id"] = "19101001"
student_2["name"] = "Random Name"

student_3 = {}
student_3["id"] = "18970097"
student_3["name"] = "Sample Name"

student_4 = {}
student_4["id"] = "21336698"
student_4["name"] = "Another Name"

student_5 = {}
student_5["id"] = "N/A"
student_5["name"] = "N/A"


--Mention the number of students in the group
number_of_students = 5