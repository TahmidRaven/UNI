
# LAB Assignment 05

This file let's you know the naming conventions and commentting processs. 

## Authors

- [@TahmidRaven](https://github.com/TahmidRaven)


## File Names
[Naming Convention](https://linktodocumentation)

* I've created .py file for each task as "Task01.py"

* if the task has subtasks then for those the files are "Task01_1.py"

* Moreover, this naming convention follows the input and outfiles with an underscore. 
    e.g. "task01_1_input.txt" 

*** Most importantly , "Please note,
there could be multiple correct sequences. You can print any valid
order that includes all the courses." Which leads me to believe that my answers for task one is CORRECT.

********************************


* Most importantly, a function named "gimmeMyoutput" or "processInputAndOutput"  was created for easier input and output processing and file creation. 

    e.g. gimmeMyoutput(input_file_path01, output_file_path01)
    processInputAndOutput(input_file_path01, output_file_path01)


## Commenting
[Comments for explainations](https://linktodocumentation)

* Comments have been added for better explainations.
* Time complexity has been provided for tasks that were asked in the assignment. 
* Handwritten comments have been added as a pdf file