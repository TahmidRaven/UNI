
# LAB Assignment 03

This file let's you know the naming conventions and commentting processs. 

## Authors

- [@TahmidRaven](https://github.com/TahmidRaven)


## File Names
[Naming Convention](https://linktodocumentation)

* I've created .py file for each task as "Task01.py"

* if the task has subtasks then for those the files are "Task01_1.py"

* Moreover, this naming convention follows the input and outfiles with an underscore. 
    e.g. "task01_1_input.txt" 

********************************


* Most importantly, a function named "allin1funcforFiles"  was created for easier input and output processing and file creation. 

    e.g. allin1funcforFiles(input_file_path01, output_file_path01)


## Commenting
[Comments for explainations](https://linktodocumentation)

* Comments have been added for better explainations.
* Time complexity has been provided for tasks that were asked in the assignment. 