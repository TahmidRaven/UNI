
# LAB Assignment 02

This file let's you know the naming conventions and commentting processs. 

## Authors

- [@TahmidRaven](https://github.com/TahmidRaven)


## File Names
[Naming Convention](https://linktodocumentation)

* I've created .py file for each task as "Task01.py"

* if the task has subtasks then for those the files are "Task01_1.py"
  * for Task 3 files were created as "task01_3_O(nlogn).py" 

* Moreover, this naming convention follows the input and outfiles with an underscore. 
    e.g. "task01_1_input.txt" 


## Commenting
[Comments for explainations](https://linktodocumentation)

* Comments have been added for better explainations.
* Time complexity has been provided for each code. 